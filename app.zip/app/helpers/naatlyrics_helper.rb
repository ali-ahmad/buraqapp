module NaatlyricsHelper
	
end