class NaatlyricsController < ApplicationController
 
end