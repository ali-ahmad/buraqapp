class AdminsController < ApplicationController
  def index
  end
end
