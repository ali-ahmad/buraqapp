class ProfileController < ApplicationController
  
  def index
      query = params[:query].presence || '*'
      @profiles = Profile.search(query)
  end


  def new
  	@profile = Profile.new
  end
  
  def create
  	@profile = Profile.new(profile_params)
  	if @profile.save
  		redirect_to profiles_path
  	end
  end

  def edit
    @profile = Profile.find params[:id]
  end

	def update

    @profile = Profile.find params[:id]
    if @profile.update_attributes params[:profile]
      flash[:notice] = 'The User is successfully updated!'
      redirect_to profiles_path
    else
      flash[:error] = @profile.errors.full_messages[0]
      redirect_to profiles_path
    end
  end

	def show
		@profile = Profile.find(params[:id])
	end


  def discontinue
    @profile = Profile.update_all({discontinued: true}, {id: params[:profile_ids]})
    redirect_to profiles_path
  end

	def destroy 
		@profile = Profile.find_by_id(params[:id])
    		if @profile.destroy
			redirect_to profiles_path
		end

	end

	def profile_params
		params.require(:profile).permit!
	end

end
