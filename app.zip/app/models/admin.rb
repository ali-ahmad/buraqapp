class Admin < ApplicationRecord

 
end
