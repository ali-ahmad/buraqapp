class Client < ApplicationRecord

end
