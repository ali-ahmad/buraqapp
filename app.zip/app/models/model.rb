class Model < ApplicationRecord

end
