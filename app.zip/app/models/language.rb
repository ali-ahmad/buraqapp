class Language < ApplicationRecord
	
	has_many :naatlyrics
	# Language.create(name: 'Urdu')

end