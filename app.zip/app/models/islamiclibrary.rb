class Islamiclibrary < ApplicationRecord
end
