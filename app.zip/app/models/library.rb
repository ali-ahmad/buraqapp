class Library < ApplicationRecord
end
