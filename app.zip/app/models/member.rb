class Member < ApplicationRecord

end